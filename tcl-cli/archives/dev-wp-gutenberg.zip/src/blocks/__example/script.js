import {renderBlock} from '../../js/app/functions.js';

renderBlock('__example__', (block, preview) => {});
