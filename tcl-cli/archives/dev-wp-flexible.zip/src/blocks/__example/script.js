const classSection = `.${tcl_ajax.prefix}-__NAME__`
document.querySelectorAll(classSection).forEach((el) => {

});
