<?php

// Do not allow directly accessing this file.
if (!defined('ABSPATH')) {
  exit('Direct script access denied.');
}

?>

</main>

<footer>

  <span class="copyright"><?php echo date('Y'); ?></span>

</footer>


<?php wp_footer(); ?>
</body>

</html>
